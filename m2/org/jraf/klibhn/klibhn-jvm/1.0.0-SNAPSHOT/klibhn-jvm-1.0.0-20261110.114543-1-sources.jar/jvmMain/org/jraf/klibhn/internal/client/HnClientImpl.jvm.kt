/*
 * This source is part of the
 *      _____  ___   ____
 *  __ / / _ \/ _ | / __/___  _______ _
 * / // / , _/ __ |/ _/_/ _ \/ __/ _ `/
 * \___/_/|_/_/ |_/_/ (_)___/_/  \_, /
 *                              /___/
 * repository.
 *
 * Copyright (C) 2026-present Benoit 'BoD' Lubek (BoD@JRAF.org)
 * and contributors (https://github.com/BoD/klibhn/graphs/contributors)
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.jraf.klibhn.internal.client

import io.ktor.client.HttpClient
import io.ktor.client.HttpClientConfig
import io.ktor.client.engine.okhttp.OkHttp
import org.jraf.klibhn.client.HnClient.Configuration.Http
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.SSLContext
import javax.net.ssl.X509TrustManager

internal actual fun createHttpClient(
  configuration: Http,
  configure: HttpClientConfig<*>.() -> Unit,
): HttpClient {
  return HttpClient(OkHttp) {
    apply(configure)
    if (configuration.bypassSslChecks) {
      engine {
        config {
          sslSocketFactory(trustAllCertsSslSocketFactory(), trustAllCerts()[0])
        }
      }
    }
  }
}

private fun trustAllCertsSslSocketFactory() = SSLContext.getInstance("SSL").apply {
  init(null, trustAllCerts(), SecureRandom())
}.socketFactory

private fun trustAllCerts() = arrayOf<X509TrustManager>(
  object : X509TrustManager {
    override fun getAcceptedIssuers(): Array<X509Certificate?> = arrayOf()
    override fun checkClientTrusted(certs: Array<X509Certificate?>?, authType: String?) {}
    override fun checkServerTrusted(certs: Array<X509Certificate?>?, authType: String?) {}
  },
)
